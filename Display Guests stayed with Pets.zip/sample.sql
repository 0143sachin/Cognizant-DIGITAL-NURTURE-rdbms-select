select guestID,resortID,(todate-fromdate) numberofdays, adultCount, childCount, petcount, totalcharge
from Booking
where petcount>0 and childCount>0
order by petcount desc; 