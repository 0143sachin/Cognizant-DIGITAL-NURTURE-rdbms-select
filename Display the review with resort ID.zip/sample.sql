select resortID,comments
from Review
where comments>'0'
order by resortID,comments;