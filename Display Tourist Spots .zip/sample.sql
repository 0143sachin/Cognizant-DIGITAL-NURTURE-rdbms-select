select pointID,describe from Pointofinterest
where closetime >= '8PM'
order by pointid;